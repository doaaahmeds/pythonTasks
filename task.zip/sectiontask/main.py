#get start
print("hello from python")
print("########################")
#to print variables
f_s="doaa"
f_age=22
print(f_s)
print(f_age)
print("########################")
#difference between print and use variable name to print
f_s
#f_age
print("########################")
#conditions
x=5
if x<0:
     print('x is positive')
elif x>1:
         print('x greater than 1')
else:
     print('x equal to 1 or 0')
#lists
print("########################")
stuent_name=["doaa","ahmed","salman"]
print(stuent_name[0])
#to get the last item in a list by using negative indexing
print(stuent_name[-2])
print("###########")
#Lists can also be sliced to get a subset of the list items
print(stuent_name[0:2])
print("############")
#using apend in list
stuent_name.append("ahmed")
print(stuent_name)
print("############")
#But we can also add items at any arbitrary index with .insert()
stuent_name.insert(2,"shimaa")
print(stuent_name)
print("############")
#Note that nothing stops us from repeatedly adding the same name to this list:
stuent_name.append("doaa")
print(stuent_name)
print("############")
#loops
for i in stuent_name:
    print(i)
print("############")
#Loops, lists, and conditionals
new_student=[]
for j in stuent_name:
    if len(stuent_name)>=4:
        new_student.append(j)


print(new_student)
print("############")

#4.3 Nested loops&pairs
new_pairs=[]
for i in stuent_name:
    for j in stuent_name:
        new_pairs.append(  (i,j) )


print(new_pairs)
print("############")
#5. Tuples
stuent_grade=(1,2,3)
print(stuent_grade)
#5.2 Unpacking
f_idx,s_idx,th_idx=stuent_grade
print(f_idx)
print(s_idx)
print(th_idx)
print("############")
student_grades =[
    ('Alice', 'Spanish', 'A'),
    ('Bob', 'French', 'C'),
    ('Carol', 'Italian', 'B+'),
    ('Dave', 'Italian', 'A-'),
]
for name,subject,gpa in student_grades:
    if(gpa.startswith('A')):
        print('Congratulations',name,'on getting ',gpa,'in',subject)

    print("############")
#6. Dictionaries
foreign_languages = {
    'Alice': 'Spanish',
    'Bob': 'French',
    'Carol': 'Italian',
    'Dave': 'Italian',
}
print(foreign_languages['Carol'])
'Zeke' in foreign_languages
print("############")
#Mutable We can add, delete, and change entries in a dictionary:
#add
foreign_languages['Esther'] = 'French'
#delete
del foreign_languages['Bob']
#change
foreign_languages['Esther'] = 'Italian'
print(foreign_languages)
print("############")
#6.4 Looping over dictionaries
for i in foreign_languages:
    value=foreign_languages[i]
    print(i, 'is taking', value)
print("############")
for i,value in foreign_languages.items():
    print(i, 'is taking', value)
print("############")
#6.5 Dictionaries as records
student_grade = ('Alice', 'Spanish', 'A')
student_name, subject, grade = student_grades[0]
print(student_name, 'got a grade of', grade, 'in', subject)
print("######")
test={
    'name':'doaa',
    'age':22
}
print(test['name'],test['age'])
print("##########")
#7. Combining Data Types
student_grades = [
    ('Alice', 'Spanish', 'A'),
    ('Bob', 'French', 'C'),
    ('Carol', 'Italian', 'B+'),
    ('Dave', 'Italian', 'A-'),
]
print(student_grades[1])
#and we can work with the individual tuples as such:
print(student_grades[0][1])

#7.2 List of dictionaries
student_grade_records = []
for i,j,k in student_grades:
    rec={
    'i':i,
    'j':j,
    'k':k
    }
    student_grade_records.append(rec)
print(student_grade_records)

#7.3 Dictionary of dictionaries
foreign_language_grades = {}
for student_name, subject, grade in student_grades:
    record = {
        'subject': subject,
        'grade': grade,
    }
    foreign_language_grades[student_name] = record

print(foreign_language_grades)







